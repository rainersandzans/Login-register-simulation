import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Auth auth = new Auth();

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Ielogoties");
            System.out.println("2. Reģistrēties");
            System.out.println("3. Iziet");

            String choice = scanner.nextLine();

            if (choice.equals("1")) {
                auth.login();
            } else if (choice.equals("2")) {
                auth.register();
            } else if (choice.equals("3")) {
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}