import java.util.ArrayList;
import java.util.Scanner;

class Auth {
    ArrayList<User> userList;

    public Auth() {
        userList = new ArrayList<>();
    }

    public void register() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter username:");
        String username = scanner.nextLine();

        System.out.println("Enter email:");
        String email = scanner.nextLine();

        System.out.println("Enter password:");
        String password = scanner.nextLine();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            System.out.println("Registration failed. Username, email, or password cannot be empty.");
            return;
        }

        Auth auth = new Auth();
        auth.validate(username, email, password);

        User newUser = new User(username, email, password);
        userList.add(newUser);

        System.out.println("Registration successful!");


    }
    public static void validate(String username, String email, String password) {
        if (username.isEmpty()) {
            System.out.println("Username cannot be empty.");
        }

        if (email.isEmpty()) {
            System.out.println("Email cannot be empty.");
        }

        if (password.isEmpty()) {
            System.out.println("Password cannot be empty.");
        }
    }
    public void login() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter email:");
        String email = scanner.nextLine();

        System.out.println("Enter password:");
        String password = scanner.nextLine();


        for (User user : userList) {
            if (user.getEmail().equals(email) && user.getPassword().equals(password)) {
                System.out.println("Sveiki, " + user.getUsername() + "!");
                return;
            }
        }

        System.out.println("Invalid email or password. Please try again.");
    }


}
